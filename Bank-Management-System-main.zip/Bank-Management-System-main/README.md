# Bank-Management-System
project in c++ without Gui

# C++ programming
This project is simply sone with C++ programming

# Without GUI
This project is done without GUI

# File Handling
With file handling , in a file, the bank record will be done
